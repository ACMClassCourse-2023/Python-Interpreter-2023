// 你需要提交这份代码
#pragma once

#include "visitor.h"

struct calculator : visitor {
    /// TODO: 完成所有需求
    ~calculator() override = default;
};
